=== Theia Post Slider ===
Requires at least: 3.0
Tested up to: 4.9
Requires PHP: 5.3
